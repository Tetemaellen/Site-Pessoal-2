document.addEventListener("DOMContentLoaded", function () {
    const colegas = [
        {
            "nome": "Gabriela",
            "imagem": "Gabriela.png"
        },
        {
            "nome": "Esdras",
            "imagem": "Esdras.png"
        },
        {
            "nome": "Franks",
            "imagem": "Franks.png"
        },
        {
            "nome": "Mauro",
            "imagem": "mauro.jpg"
        }
    ];

    function carregarColegas() {
        const colegasContainer = document.getElementById('colegas-container');
        colegas.forEach(colega => {
            const card = `
                <div class="card col-md-3">
                    <img src="${colega.imagem}" class="card-img-top" alt="${colega.nome}">
                    <div class="card-body">
                        <h5 class="card-title">${colega.nome}</h5>
                    </div>
                </div>
            `;
            colegasContainer.innerHTML += card;
        });
    }

    const imagensCarrossel = [
        {
            "src": "https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEh-FUdWTSc8g-Zc29e2MP-FIjyekk5bki6VFjTPej-PnMWulrURaf_V_iIEr_SEYTRJaVofEYbuwsv7GPhy1M0sAUAfXBZzuzxJOqVGgMiY_iIKq_lxsDfo0DVpGLuL_rmKHXiuv2RjHuP6/s1600/gequipe1.jpg",
            "alt": "Primeiro slide"
        },
        {
            "src": "https://portaleducacao.vteximg.com.br/arquivos/ids/157376/curso-online-dinamicas-de-grupo.jpg?v=636573227268270000",
            "alt": "Segundo slide"
        },
        {
            "src": "https://lh4.googleusercontent.com/proxy/iiHK0Uqp9tmHR-jHj5TX9yZJxtAVAe3wanJ20IhhTzP6osxlLZTYvPO5Fq46by78t3sDageIX5WYMgOwa9a3ZSkIlvnswDBITB4gtRdrLzc3RcAbpcc",
            "alt": "Terceiro slide"
        },
        {
            "src": "https://i.gifer.com/9lOK.gif",
            "alt": "Quarto slide"
        },
        {
            "src": "https://i.pinimg.com/originals/95/bd/2e/95bd2ebefd51d16d55eb578d3ae469c7.gif",
            "alt": "Quinto slide"
        }
    ];

    function carregarCarrossel() {
        const carouselIndicators = document.getElementById('carousel-indicators');
        const carouselInner = document.getElementById('carousel-inner');

        imagensCarrossel.forEach((imagem, index) => {
            const indicator = `<li data-target="#carouselExampleIndicators" data-slide-to="${index}" class="${index === 0 ? 'active' : ''}"></li>`;
            const slide = `
                <div class="carousel-item ${index === 0 ? 'active' : ''}">
                    <img class="d-block w-100" src="${imagem.src}" alt="${imagem.alt}">
                </div>
            `;
            carouselIndicators.innerHTML += indicator;
            carouselInner.innerHTML += slide;
        });
    }

    carregarColegas();
    carregarCarrossel();
});
